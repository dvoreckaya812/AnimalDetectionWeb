class Animal:

    def __init__(self, name, img, info):
        self.name = name
        self.img = img
        self.info = info
